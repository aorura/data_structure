package com.ds.graph;

public class Edge<V, E> {

	private V end;
	private V start;
	private Object weight;

	public Edge(V start, V end, E weight) {
		this.start = start;
		this.end = end;
		this.weight = weight;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("(" + start + ","	+ end + ", " + weight + ")");
		return sb.toString();
	}
	
}





