package com.ds.graph;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;

public class UndirectGraphMatrix<V, E extends Comparable<E>>
		implements
		Graph<V, E> {
	final ArrayList<V> mVertexList = new ArrayList<>();
	final ArrayList<ArrayList<E>> mMatrix= new ArrayList<>();
	
	@Override
	public void addVertex(V vertex) {
		if(mVertexList.contains(vertex)){
			throw new IllegalStateException("already added");
		}
		
		mVertexList.add(vertex);
		mMatrix.add(new ArrayList<E>());
	}

	@Override
	public void addEdge(V start, V end,E weight) {
		int starti = mVertexList.indexOf(start);
		
		if (starti < 0) {
			throw new IllegalStateException("invalid vertex");
		}

		int endi = mVertexList.indexOf(end);
		if (endi < 0) {
			throw new IllegalStateException("invalid vertex");
		}
		
		_addEdge(starti, endi, weight);
		_addEdge(endi, starti, weight);
	}

	private void _addEdge(int starti,int endi, E weight) {
		ArrayList<E> row = mMatrix.get(starti);
		//row.size() = 0
		//vertex ũ�⸸ŭ �迭�� �ø��� �ȴ�
		while(row.size()<mMatrix.size()){
			row.add(null);
		}
		
		row.set(endi, weight);
	}

	@Override
	public Iterator<V> adjacent(V vertex) {
		ArrayList<V> r = new ArrayList<>();
		
		//vertex�� ������ vertex����Ʈ�� ���Ѵ�
		int rowI = mVertexList.indexOf(vertex);
		ArrayList<E> row = mMatrix.get(rowI);//row
		for (int i = 0; i < row.size(); i++) {
			if(Objects.isNull(row.get(i)) == false ){//null !=üũ
				r.add(mVertexList.get(i));
			}
		}
		
		return r.iterator();
	}

	@Override
	public Iterator<Edge<V, E>> incident(V start) {
		ArrayList<Edge<V, E>> r = new ArrayList<>();
		ArrayList<E> row = mMatrix.get(mVertexList.indexOf(start));
		
		for (int i = 0; i < row.size(); ++i) {
			if(row.get(i) != null){
				r.add(
	new Edge<V, E>(start, mVertexList.get(i), row.get(i))  );
			}
			// null�� �ƴ� vertex�� r�� �߰��ϱ�
		}
		return r.iterator();
	}

	@Override
	public boolean isAdjacent(V start, V end) {
		int rowI = mVertexList.indexOf(start);
		int colI = mVertexList.indexOf(end);
		
		if (rowI < 0) {
			throw new IllegalStateException("rowI < 0");
		}
		
		if (colI < 0) {
			throw new IllegalStateException("colI < 0");
		}
		
		if(rowI >= mMatrix.size()){
			throw new IllegalStateException("rowI >= mMatrix.size()");
		}
		
		if(colI >= mMatrix.get(rowI).size()){
			throw new IllegalStateException("colI >= mMatrix.get(rowI).size()");
		}
		
		
		return Objects.isNull(mMatrix.get(rowI).get(colI)) == false;
	}

	@Override
	public int orderIn(V v) {
		return orderOut(v);
	}

	@Override
	public int orderOut(V v) {
		int cnt = 0;
		//order ���ϱ�
		Iterator<V> vertexes = adjacent(v);//adjacent vertexs
		while(vertexes.hasNext()){
			vertexes.next();
			++cnt;
		}
		
		return cnt;
	}

	@Override
	public int getVertexSize() {
		// TODO Auto-generated method stub
		return 0;
	}

}











