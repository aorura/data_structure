package com.ds.graph.mst;

import java.util.List;

import edu.uci.ics.jung.algorithms.shortestpath.DijkstraShortestPath;
import edu.uci.ics.jung.graph.DirectedSparseGraph;

public class MainGraph {
	public static void main(String ...args){
		DirectedSparseGraph<String, Integer>
			g = new DirectedSparseGraph();
		g.addVertex("A"); g.addVertex("B");
		g.addVertex("C");
		g.addEdge(5, "A","B");
		g.addEdge(4, "B","C"); // A >5> B >5> C
		g.addEdge(9, "A","C");
		System.out.println(g.toString());
		
		DijkstraShortestPath<String, Integer>
		 dsp = new DijkstraShortestPath<>(g);
		List<Integer> path = dsp.getPath("A", "C");
		System.out.println(path);
	}
}









