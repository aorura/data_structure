package com.ds.graph;

public class Edge<V, E> {
	
}
