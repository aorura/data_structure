package com.ds.graph;

import java.util.ArrayList;
import java.util.Iterator;

public class UndirectGraphMatrix<V, E extends Comparable<E>>
		implements
		Graph<V, E> {
	final ArrayList<V> mVertexList = new ArrayList<>();
	final ArrayList<ArrayList<E>> mMatrix= new ArrayList<>();
	
	@Override
	public void addVertex(V vertex) {
		mVertexList.add(vertex);
		mMatrix.add(new ArrayList<E>());
	}

	@Override
	public void addEdge(V start, V end,E weight) {
		int starti = mVertexList.indexOf(start);
		int endi = mVertexList.indexOf(end);
		
		_addEdge(starti, endi, weight);
		_addEdge(endi, starti, weight);
	}

	private void _addEdge(int starti,int endi, E weight) {
		ArrayList<E> row = mMatrix.get(starti);
		//row.size() = 0
		//vertex ũ�⸸ŭ �迭�� �ø��� �ȴ�
		while(row.size()<mMatrix.size()){
			row.add(null);
		}
		
		row.set(endi, weight);
	}

	@Override
	public Iterator<V> adjacent(V vertex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterator<Edge<V, E>> incident(
			V start) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isAdjacent(V start,
			V end) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int orderIn(V v) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int orderOut(V v) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getVertexSize() {
		// TODO Auto-generated method stub
		return 0;
	}

}
