package com.ds.graph;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;

public class DirectGraphMatrix
		<V, E extends Comparable<E>>
	extends UndirectGraphMatrix<V,E>{
	
	public void addEdge(V start, V end,E weight) {
		int starti = mVertexList.indexOf(start);
		
		if (starti < 0) {
			throw new IllegalStateException("invalid vertex");
		}

		int endi = mVertexList.indexOf(end);
		if (endi < 0) {
			throw new IllegalStateException("invalid vertex");
		}
		
		_addEdge(starti, endi, weight);
	}
	
	@Override
	public int orderIn(V v) {
		int cnt = 0;
		//order ���ϱ�
		int rowSize = mMatrix.size();
		int colIndex = mVertexList.indexOf(v);
		
		for (int r = 0; r < rowSize; ++r) {
			ArrayList<E> row = mMatrix.get(r);
			if(row.size() < mMatrix.size()){
				continue;
			}
			
			if(Objects.isNull(row.get( colIndex ))== false){
				++cnt;
			}
		}
		/*
		
		Iterator<V> vertexes = adjacent(v);
		while(vertexes.hasNext()){
			vertexes.next();
			++cnt;
		}
		*/
		return cnt;
	}
}










