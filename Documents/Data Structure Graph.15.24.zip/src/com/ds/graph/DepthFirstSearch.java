package com.ds.graph;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Objects;
import java.util.TreeMap;

public class DepthFirstSearch
	<V, E extends Comparable<E>>
		implements GraphTraversal<V, E> {

	private Graph<V, E> graph;
	private V start;

	public DepthFirstSearch(
			Graph<V, E> g, V start) {
		this.graph = g;
		this.start = start;
	}

	@Override
	public V startVertex() {
		return this.start ;
	}

	@Override
	public Iterator<V> path() {
		return mPath.iterator();
	}

	TreeMap<V, Boolean> mVisited = new TreeMap<>();
	ArrayList<V> mPath = new  ArrayList<>();
	
	@Override
	public void run() {
		_run(this.start);
	}
	
	private void _run(V v){
		//v ������� ǥ��
		mVisited.put(v, Boolean.TRUE);
		//path�� �߰�
		mPath.add(v);
		
		Iterator<V> iter = this.graph.adjacent(v);
		while(iter.hasNext()){//while(){
			V w = iter.next();
			Boolean isVisited = mVisited.get(w);
			if(Objects.isNull(isVisited) ||
					//isVisited.equals(Boolean.FALSE)
					Boolean.FALSE.equals(isVisited)
					){// if(isVisited == false){
				// _run(v);
				_run(w);
			}//}
		}//}
	}	
}














