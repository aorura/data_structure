package com.ds.graph;

import java.util.Iterator;

public class UndirectGraphMatrixMain {

	public static void main(
			String[] args) {
		UndirectGraphMatrix<String, Integer>
			g = new UndirectGraphMatrix<>();
		
		//�׷��� �����--����(�̷�,�ǽ�)
		g.addVertex("0");g.addVertex("1");
		g.addVertex("2");g.addVertex("3");//g.addVertex("3");
		
		g.addEdge("0", "1", 1);g.addEdge("1", "3", 1);
		g.addEdge("2", "1", 1);g.addEdge("2", "3", 1);
		g.addEdge("3", "0", 1);g.addEdge("3", "1", 1);
		
		
		//�׷��� �׽�Ʈ--������-����(�̷�)-����(�ǽ�);
		System.out.println("orderIn(1)="+g.orderIn("1"));
		System.out.println("isAdjacent(1,2)="+g.isAdjacent("1", "2"));
		System.out.println("isAdjacent(0,2)="+g.isAdjacent("0", "2"));
		
		Iterator<Edge<String, Integer>> incidents = g.incident("3");
		while (incidents.hasNext()) {
			Edge<String,Integer> edge =
					(Edge<String, Integer>) incidents.next();
			System.out.println(edge+", ");
			
		}
		//incidents.forEachRemaining(e->System.out.println(""+e));
	}

}








