package com.ds.binarytree;

public class BinarySearchingTree
	<K extends Comparable<K>, V> {

	public Node<K, V> mRoot;

	public V get(K key) {
		Node<K, V> cur = mRoot;
		while(cur != null){
			if(cur.mKey == key){
				return cur.mValue;
			}
			
			if (key.compareTo(cur.mKey) < 0) {
				cur = cur.mLeft;
			}else{
				cur = cur.mRight;
			}
		}
		return null;
	}

	public void put(K key, V value) {
		Node<K, V> cur = mRoot;
		Node<K, V> parent=null;// ������ġ
		
		while(cur != null){// --> !Objects.isNull(cur)
			if (key.compareTo(cur.mKey) == 0) {
				return;
			}
			parent = cur; // parent is null
			if (key.compareTo(cur.mKey) < 0) {
				cur = cur.mLeft;
			}else{
				cur = cur.mRight;
			}
		}
		
		Node<K, V> n = new Node<K, V>(key, value);
		if(mRoot == null){// ctrl + F11
			mRoot = n;
			return;
		}
		
		if (n.mKey.compareTo(parent.mKey) < 0) {
			parent.mLeft = n;
		}else{
			parent.mRight = n;
		}
	}

	public boolean remove(K key) {
		isRemoved = false;
		mRoot = _deleteChild(mRoot, key);
		
		return isRemoved;
	}
	
	boolean isRemoved = false;
	/*
	 *        5
	 *  null    null
	 */
	private Node<K, V> _deleteChild(
			Node<K, V> cur, K key) { // ---1
		Node<K, V> target = null;
		
		if(cur == null){
			return null;//return ull
		}

		if (key.compareTo(cur.mKey) < 0) {//      --- 2.1
			target = _deleteChild(cur.mLeft, key);
			cur.mLeft = target;
		} else if (key.compareTo(cur.mKey) > 0) {//-- 2.2
			target = _deleteChild(cur.mRight, key);
			cur.mRight = (target == null)? null: target;
		}  else if (key.compareTo(cur.mKey) == 0) {//-- 2.3
			this.isRemoved = true;
			if (cur.mLeft == null && cur.mRight == null){
				return null;//order = 0
			} else if(cur.mLeft != null && cur.mRight == null) {
				return cur.mLeft;//order 1
			} else if(cur.mLeft == null && cur.mRight != null) {
				return cur.mRight;//order 1
			} else {//if(cur.mLeft != null && cur.mRight != null){
				//TODO order 2 
				Node<K, V> maxNode = _findMax(cur.mLeft);
				//����� ���(successor)�� �ִٸ�(maxNode!=null);
				if(maxNode != null){
					return maxNode;//successor�� return�Ѵ�
				}
				
				Node<K, V> minNode = _findMin(cur.mRight);
				if(minNode != null){
					return minNode;
				}
			}
		}
		
		return cur;
	}

	private Node<K, V> _findMin(
			Node<K, V> cur) {
		if(cur == null){
			return null;
		}
		
		if(cur.mLeft !=null){
			return _findMin(cur.mLeft);
		}
		
		return cur;
	}

	//���� ��ġ cur ��������, ���� Ʈ������ ���� ū Key�� ���� ��� 
	private Node<K, V> _findMax(
			Node<K, V> cur) {
		if(cur == null){
			return null;
		}
		
		if(cur.mRight !=null){
			return _findMax(cur.mRight);
		}
		
		return cur;
	}
	

}

class Node<K extends Comparable<K>, V> {

	public Node<K, V> mLeft;
	public Node<K, V> mRight;
	public K mKey;
	public V mValue;

	public Node(K key, V value) {
		this.mKey = key;
		this.mValue = value;
	}

}












