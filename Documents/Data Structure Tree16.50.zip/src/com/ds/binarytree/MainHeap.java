package com.ds.binarytree;

import java.util.PriorityQueue;

public class MainHeap {
	transient int fff = 0;
	volatile Object ffff = null;
	
	public static void main(
			String[] args) {
		PriorityQueue<Integer> pq = new PriorityQueue<>(); 
		pq.add(45);
		pq.add(35);
		pq.add(95);
		pq.add(70);
		
		System.out.println("pq.poll()=" + pq.poll());
		System.out.println("pq.poll()=" + pq.poll());
		System.out.println("pq.poll()=" + pq.poll());
		System.out.println("pq.poll()=" + pq.poll());
		
	}
}









