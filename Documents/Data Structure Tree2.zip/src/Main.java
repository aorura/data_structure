import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeMap;


public class Main {

	class Node{
		Integer key;
		String value;
	}
	public static void main(
			String[] args) {
		ArrayList<Node>
			list = new ArrayList<>();
		
		TreeMap<Integer, String> map
		= new TreeMap<>();
		map.put(8, "5");
		map.put(4, "2");
		map.put(10, "7");
		map.put(1, "1");
		map.put(3, "3");
		//.........
		map.remove(4);
		Iterator<Integer> iter = map.keySet().iterator();
		
		while(iter.hasNext()){
			System.out.println("map="+
						iter.next());
		}
	}

}









