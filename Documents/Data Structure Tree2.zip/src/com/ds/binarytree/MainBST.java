package com.ds.binarytree;

public class MainBST {

	public static void main(
			String[] args) {

		BinarySearchingTree<Integer, String>
			bst = new BinarySearchingTree<>();

		//TODO insert
		bst.put(8, "8");
		bst.put(4, "4");
		bst.put(10, "10");
		bst.put(2, "2");
		bst.put(6, "6");
		bst.put(14, "14");
		bst.put(11, "11");
		bst.put(16, "16");
		
		//XXX find
		System.out.println("bst.get(6)="
					+ bst.get(6));
		System.out.println("bst.get(11)="
				+ bst.get(11));
		System.out.println("bst.remove(15)="
				+ bst.remove(16));
		
	}

}










