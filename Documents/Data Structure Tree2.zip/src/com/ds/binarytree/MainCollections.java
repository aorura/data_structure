package com.ds.binarytree;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class MainCollections {

	public static void main(
			String[] args) {
		//new MainCollections().travser();
		//new MainCollections().testIterationString();
		new MainCollections().testStream();
		
	}
	
	private void testStream(){
		Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
			.findFirst()
				.ifPresent(System.out::println);
		
		IntStream.range(1, 10)
			.findFirst()
				.ifPresent(System.out::println);
		
		Arrays.stream(new int[]{1, 2, 3})
			.map(n->2*n+1)
				.average()
					.ifPresent(System.out::println);
		
		Stream.of("a1", "a2", "a3", "a4", "a5")
			.map(s->s.substring(1))
				.mapToInt(Integer::parseInt)
					.average();
		
	}
	
	
	private void testIterationString(){
		List<Integer> list 
			= Arrays.asList(55, 5, 2, 3);
		list.stream()
			.forEach(
				action->System.out.format("%d, ",action));
	}
	

	private void travser(){
		ArrayList<Integer> list 
		= new ArrayList<>();
	list.add(55);list.add(5);list.add(2);list.add(3);
	
	for(int i =0;i<10;++i){
		System.out.println(list.get(i));
	}
	
	Iterator<Integer> iter = list.iterator();
	while (iter.hasNext()) {
		Integer integer = (Integer) iter.next();
	}
	
	for (Integer integer : list) {
		System.out.println(integer);
	}
	TreeMap<Integer, String> tremap = new TreeMap<>();
	list.stream().forEach(c->System.out.println(c));
//	list.stream().forEach(gggg(Integer c){tremap.put(c, c+"")});
	//list.stream().forEach((c)->tremap.put(c, c+"")));	
	}
}
