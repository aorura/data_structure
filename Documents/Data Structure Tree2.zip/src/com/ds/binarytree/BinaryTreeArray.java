package com.ds.binarytree;

import java.lang.reflect.Array;
import java.util.Objects;

public class BinaryTreeArray<T>
		implements BinaryTree<T> {

	private int mHeight;
	private int mCapacity;
	public Object[] mData;
	private int mIndexCur;

	public BinaryTreeArray(int height) {
		this.mHeight = height;
		this.mCapacity = (int) Math
				.pow(2, height + 1);
		this.mData = (Object[]) Array
				.newInstance(
						Object.class,
						this.mCapacity);
		this.mIndexCur = 1;

	}

	@Override
	public int height() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int edges() {
		return size() - 1;
	}

	@Override
	public int size() {
		return this.mIndexCur - 1;
	}

	// ctrl + shift + F
	@Override
	public boolean add(Object item) {
		if (this.mIndexCur < this.mData.length) {
			this.mData[this.mIndexCur++] = item;
			return true;
		}
		return false;
	}

	@Override
	public T get() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEmpty() {
		return this.mIndexCur <= 1;
	}

	public void preoder() {
		System.out.print("preoder()=");
		_preorder(1);
		System.out.println();
	}

	private void _preorder(int i) {
		if(i >= this.mData.length){
			return;
		}
		
		if(Objects.isNull(this.mData[i])) {//guava
			return;
		}
		
		// pre-order
		// 1. process
		System.out.print(this.mData[i]+", ");
		// 2. left
		_preorder(2 * i);
		// 3. right
		_preorder(2 * i + 1);

		// in-order
		// 1. left
		// 2. process
		// 3. right

		// post-order
		// 1. left
		// 2. right
		// 3. process
	}

	public void inorder() {
		System.out.print("inoder()=");
		_inorder(1);
		System.out.println();
		
	} // Vistor

	private void _inorder(int i) {
		if(i >= this.mData.length){
			return;
		}
		
		if(Objects.isNull(this.mData[i])) {//guava
			return;
		}
		// in-order
		// 1. left
		_inorder(2 * i);
		// 2. process
		System.out.print(this.mData[i]+", ");
		// 3. right
		_inorder(2 * i + 1);

	}
	
}









